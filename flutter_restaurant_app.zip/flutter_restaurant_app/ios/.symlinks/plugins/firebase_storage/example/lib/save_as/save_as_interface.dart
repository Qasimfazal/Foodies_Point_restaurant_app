// ignore_for_file: require_trailing_commas
// @dart=2.9
import 'dart:typed_data';

/// Present a dialog so the user can save as... a bunch of bytes.
Future<void> saveAsBytes(Uint8List bytes, String suggestedName) async {
  return;
}
