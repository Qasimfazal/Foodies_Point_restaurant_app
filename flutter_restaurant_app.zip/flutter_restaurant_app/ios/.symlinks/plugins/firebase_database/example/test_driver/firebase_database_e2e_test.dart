// ignore_for_file: require_trailing_commas
// @dart = 2.9
import 'package:drive/drive_driver.dart' as drive;

void main() => drive.main();
