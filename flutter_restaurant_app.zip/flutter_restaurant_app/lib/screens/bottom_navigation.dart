import 'package:flutter/material.dart';
import 'package:flutter_restaurant_app/screens/about_screen.dart';
import 'package:flutter_restaurant_app/screens/user_home_screen.dart';
import 'package:flutter_restaurant_app/screens/user_order_screen.dart';
import 'package:flutter_restaurant_app/screens/user_profile_screen.dart';


class Bottom_Navigation_Screen extends StatefulWidget {
  const Bottom_Navigation_Screen({Key? key}) : super(key: key);

  @override
  _Bottom_Navigation_ScreenState createState() => _Bottom_Navigation_ScreenState();
}

class _Bottom_Navigation_ScreenState extends State<Bottom_Navigation_Screen> {
  int _selectedIndex = 0;
  List<Widget> _widgetOptions = <Widget>[
    User_Home(),
    User_Order(),
    User_Profile_Screen(),
    About_Screen(),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            label: 'Home',
            activeIcon: Icon(Icons.home),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark_border_outlined),
            label: 'Order',
            activeIcon: Icon(Icons.bookmark),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: 'Profile',
            activeIcon: Icon(Icons.person_rounded),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info_outline),
            label: 'About',
            activeIcon: Icon(Icons.info),
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFFD1413A),
        unselectedItemColor: Colors.grey,
        unselectedLabelStyle: TextStyle(color: Colors.grey),
        onTap: _onItemTapped,
      ),
    );
  }
}
