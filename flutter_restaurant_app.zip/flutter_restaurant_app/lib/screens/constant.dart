
import 'package:flutter/material.dart';

class Constant{
  static String name  = "";
  static String totalOrder = "";
  static String type =  "";
  static String tKey = "";
  static String selectDate = "";
  static String selectTime = "";
  static String userID = "";
  static String tImage= "";
  static String tSeat = "";
  static String rName = "";
  static String rAddress = "";
  static String rDes = "";
  static String rImageURl = "";
  static String restaurantID = "";
  static String rKey = "";
  static String rUID = "";
  static String tno = "";
  static String uLastName = "";
  static String uAddress = "";
  static String uPhone ="";
  static String rrID ="";



  static TextEditingController textEditingControllerUsername = new TextEditingController();
  static TextEditingController textEditingControllerAddress = new TextEditingController();
  static TextEditingController textEditingControllerZipCode = new TextEditingController();
  static TextEditingController textEditingControllerState = new TextEditingController();
  static TextEditingController textEditingControllerCountry = new TextEditingController();
  static TextEditingController textEditingControllerEmail = new TextEditingController();
  static TextEditingController textEditingControllerPhoneNumber = new TextEditingController();
}
